package com.example.webdevs1serverjava.model;

public enum Role {
	FACULTY,STUDENT,ADMIN;
}
