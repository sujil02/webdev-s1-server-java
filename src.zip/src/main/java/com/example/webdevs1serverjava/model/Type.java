package com.example.webdevs1serverjava.model;

public enum Type {
	HEADING,LIST,PARAGRAPH,IMAGE,LINK
}
